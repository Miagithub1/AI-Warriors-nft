# AI Warriors — Premium V3

Included:
- Premium responsive NFT landing page
- 24 showcase NFT artworks included as fast-loading 2048x2048 SVG assets
- Rarity filters, search, full-screen preview
- X / Discord / OpenSea buttons (replace placeholders)
- Mint button ready for your real OpenSea Drop / launchpad URL
- IPFS metadata structure for the full 10K collection
- Performance-friendly lazy-loaded gallery

IMPORTANT:
The included 24 artworks are showcase/vector assets so the ZIP stays fast. For the actual 10K NFT launch, replace them with your final 2K/4K PNG/WebP artwork and upload the collection to IPFS. The website can display optimized thumbnails while the NFT metadata points to the original IPFS files.

Set these values in app.js:
SITE_LINKS.x
SITE_LINKS.discord
SITE_LINKS.opensea
MINT_URL
